package manager;

import java.util.ArrayList;
import model.Player;

public class PlayerManager {

    private ArrayList<Player> players;

    public PlayerManager() {
        players = new ArrayList<>();
    }

    public void addPlayer(Player player) {
        players.add(player);
    }

    public void displayPlayers() {
        if (players.isEmpty()) {
            System.out.println("No players found.");
            return;
        }

        for (Player p : players) {
            System.out.println("-------------------");
            System.out.println("ID: " + p.getPlayerId());
            System.out.println("Name: " + p.getFullName());
            System.out.println("Type: " + p.getPlayerType());
        }
    }

    public Player findPlayerById(String id) {
        for (Player p : players) {
            if (p.getPlayerId().equalsIgnoreCase(id)) {
                return p;
            }
        }
        return null;
    }

    public boolean removePlayer(String id) {
        Player p = findPlayerById(id);

        if (p != null) {
            players.remove(p);
            return true;
        }

        return false;
    }
    public void updatePlayer(String id,
                         String position,
                         int shirtNumber,
                         double salary) {

    Player p = findPlayerById(id);

    if (p != null) {
        p.setPosition(position);
        p.setShirtNumber(shirtNumber);
        p.setBaseSalary(salary);

        System.out.println("Updated!");
    } else {
        System.out.println("Player not found!");
    }
}
  public void deactivatePlayer(String id){

    Player p = findPlayerById(id);

    if(p!=null){

        p.setStatus("Inactive");

        System.out.println("Player deactivated.");

    }else{

        System.out.println("Player not found.");
    }

}
public ArrayList<Player> getAllPlayers() {
    return players;
}  
}