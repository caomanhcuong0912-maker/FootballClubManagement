package main;

import manager.PlayerManager;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
Scanner sc = new Scanner(System.in);
PlayerManager manager = new PlayerManager();
int choice;
do {

    System.out.println("\n===== PLAYER MANAGEMENT =====");
    System.out.println("1. Add Player");
    System.out.println("2. View Players");
    System.out.println("3. Update Player");
    System.out.println("4. Remove Player");
    System.out.println("5. Deactivate Player");
    System.out.println("0. Exit");

    System.out.print("Choose: ");
    choice = Integer.parseInt(sc.nextLine());

    switch (choice) {

        case 1:
            break;

        case 2:
            break;

        case 3:
            break;

        case 4:
            break;

        case 5:
            break;

        case 0:
            System.out.println("Goodbye!");
            break;

        default:
            System.out.println("Invalid choice!");
    }

} while (choice != 0);
        
    }
}