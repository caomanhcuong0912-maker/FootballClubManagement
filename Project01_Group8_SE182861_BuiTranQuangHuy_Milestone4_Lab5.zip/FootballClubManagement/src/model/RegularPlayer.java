package model;

public class RegularPlayer extends Player {

    public RegularPlayer(String playerId,
                         String fullName,
                         int age,
                         String nationality,
                         String position,
                         int shirtNumber,
                         double baseSalary,
                         String status) {

        super(playerId, fullName, age,
                nationality, position,
                shirtNumber, baseSalary,
                status);
    }

    @Override
    public double calculateBonus(int points) {
        return 0;
    }

    @Override
    public String getPlayerType() {
        return "Regular Player";
    }
}