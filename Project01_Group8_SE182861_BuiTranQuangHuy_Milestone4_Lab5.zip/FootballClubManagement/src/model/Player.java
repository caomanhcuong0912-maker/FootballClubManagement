package model;

public abstract class Player {

    protected String playerId;
    protected String fullName;
    protected int age;
    protected String nationality;
    protected String position;
    protected int shirtNumber;
    protected double baseSalary;
    protected String status;

    public Player() {
    }

    public Player(String playerId, String fullName, int age,
                  String nationality, String position,
                  int shirtNumber, double baseSalary,
                  String status) {

        this.playerId = playerId;
        this.fullName = fullName;
        this.age = age;
        this.nationality = nationality;
        this.position = position;
        this.shirtNumber = shirtNumber;
        this.baseSalary = baseSalary;
        this.status = status;
    }

    public abstract double calculateBonus(int points);

    public String getPlayerId() {
        return playerId;
    }

    public String getFullName() {
        return fullName;
    }

    public int getAge() {
        return age;
    }

    public String getNationality() {
        return nationality;
    }

    public String getPosition() {
        return position;
    }

    public int getShirtNumber() {
        return shirtNumber;
    }

    public double getBaseSalary() {
        return baseSalary;
    }

    public String getStatus() {
        return status;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public void setShirtNumber(int shirtNumber) {
        this.shirtNumber = shirtNumber;
    }

    public void setBaseSalary(double baseSalary) {
        this.baseSalary = baseSalary;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public abstract String getPlayerType();
}